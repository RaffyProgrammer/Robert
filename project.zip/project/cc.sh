clear
echo "Loading";
sleep 0.5
clear
echo "Loading.";
sleep 0.5
clear
echo "Loading..";
sleep 0.5
clear
echo "Loading...";
sleep 1
clear
echo "Loading";
sleep 0.5
clear
echo "Loading.";
sleep 0.5
clear
echo "Loading..";
sleep 0.5
clear
echo "Loading...";
sleep 1
clear

echo "Hello!"
sleep 1
clear

bash ccc.sh