sleep 1
clear
echo "Ketika hidup memberimu "
echo "seratus alasan untuk menangis, "
echo "tunjukkan pada dunia bahwa kamu "
echo "memiliki seribu alasan untuk tersenyum"
sleep 1
echo "shutting down"
sleep 0.5
echo "shutting down."
sleep 0.5
echo "shutting down.."
sleep 0.5
echo "shutting down..."
sleep 0.5
echo "shutting down.."
sleep 0.5
echo "shutting down."
sleep 0.5
echo "shutting down"
sleep 2
clear